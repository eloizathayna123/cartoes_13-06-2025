criaCartao(
'Programacao',
'O que e JavaScript?',
'JavaScript e uma linguagem de programacao.'
);
criaCartao(
'Geografia',
'Qual a capital da Franca?',
'A capital da Franca e Paris.'
);
criaCartao('Programacao',
'O que e uma funcao?',
'Uma funcao e um bloco de codigo que executa uma tarefa.'
);
